<?php get_header();?>

<section class="sample-text-area">
<?php while(have_posts()): the_post();global $post;?>
		<div class="container box_1170">
			<h3 class="text-heading"><?php the_title();?></h3>
			<p class="sample-text">
			<?php the_content();?>
			</p>
        </div>
                <?php endwhile;?>

                <?php $defaults = array(
                'before'           => '<p class="text-center">' . __( 'Pages:', 'news-wp' ),
                'after'            => '</p>',
                ); wp_link_pages( $defaults ); wp_link_pages();?>

<?php if(comments_open() || get_comments_number()){
                 comments_template();
             }?>


	</section>



<?php get_footer();?>