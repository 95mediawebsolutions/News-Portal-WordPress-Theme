<?php 


function news_enqueue(){
    // Adding Javascript Files
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '3.3.7', true);
    wp_enqueue_script('modernizr', get_template_directory_uri() . '//assets/js/vendor/modernizr-3.5.0.min.js', array('jquery'), '1.0', true);
    wp_enqueue_script('popper', get_template_directory_uri() . '/assets/js/popper.min.js', array(), '1.0', true);
    wp_enqueue_script('slicknav', get_template_directory_uri() . '/assets/js/jquery.slicknav.min.js', array(), '1.0', true);
    wp_enqueue_script('slick', get_template_directory_uri() . '/assets/js/slick.min.js', array(), '1.0', true);
    wp_enqueue_script('owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array(), '1.0', true);
    wp_enqueue_script('gijgo', get_template_directory_uri() . '/assets/js/gijgo.min.js', array(), '1.0', true);
    wp_enqueue_script('wow', get_template_directory_uri() . '/assets/js/wow.min.js', array(), '1.0', true);
    wp_enqueue_script('animated-headline', get_template_directory_uri() . '/assets/js/animated.headline.js', array(), '1.0', true);
    wp_enqueue_script('jquery-magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.js', array(), '1.0', true);
    wp_enqueue_script('jquery-scrollUp', get_template_directory_uri() . '/assets/js/jquery.scrollUp.min.js', array(), '1.0', true);
    wp_enqueue_script('jquery-nice-select', get_template_directory_uri() . '/assets/js/jquery.nice-select.min.js', array(), '1.0', true);
    wp_enqueue_script('jquery-sticky', get_template_directory_uri() . '/assets/js/jquery.sticky.js', array(), '1.0', true);
    wp_enqueue_script('plugins', get_template_directory_uri() . '/assets/js/plugins.js', array(), '1.0', true);
    wp_enqueue_script('main-js', get_template_directory_uri() . '/assets/js/main.js', array(), '1.0', true);

    // Adding CSS Files
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/css/bootstrap.min.css');
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css?family=Open+Sans:400,700%7CLato:300,400');
    wp_enqueue_style('google-fonts-2', 'https://fonts.googleapis.com/css?family=Inconsolata:700');
    wp_enqueue_style('google-fonts-3', 'https://fonts.googleapis.com/css?family=Barlow:300,400,500,600,700,800,900|Roboto:100,300,400,500,700&display=swap');
    wp_enqueue_style('carousel-css', get_template_directory_uri() . '/assets/css/owl.carousel.min.css');
    wp_enqueue_style('ticker-style', get_template_directory_uri() . '/assets/css/ticker-style.css');
    wp_enqueue_style('flaticon', get_template_directory_uri() . '/assets/css/flaticon.css');
    wp_enqueue_style('slicknav', get_template_directory_uri() . '/assets/css/slicknav.css');
    wp_enqueue_style('animate', get_template_directory_uri() . '/assets/css/animate.min.css');
    wp_enqueue_style('fontawesome', get_template_directory_uri() . '/assets/css/fontawesome-all.min.css');
    wp_enqueue_style('themify-icons', get_template_directory_uri() . '/assets/css/themify-icons.css');
    wp_enqueue_style('slick', get_template_directory_uri() . '/assets/css/slick.css');
    wp_enqueue_style('nice-select', get_template_directory_uri() . '/assets/css/nice-select.css');
    wp_enqueue_style('main-style', get_template_directory_uri() . '/assets/css/style.css');
    wp_enqueue_style('main', get_template_directory_uri() . '/style.css');
}