<?php 

function news_social_customizer_section($wp_customize){
    $wp_customize->add_setting('news_facebook_handle',[
        'default'     => '',
        'sanitize_callback' => 'esc_url_raw'
    ]);

    $wp_customize->add_section('news_social_section', [
        'title'             =>   __('News Social Settings', 'news-wp'),
        'priority'          =>   30,
        'panel'             => 'news_wp'
    ]);


    $wp_customize->add_control(new WP_Customize_Control(
            $wp_customize,
            'news_social_facebook_input',
            array(
                'label'          => __( 'Facebook Handle', 'news-wp' ),
                'section'        => 'news_social_section',
                'settings'       => 'news_facebook_handle',
                'type'           => 'url',
                
            )
        )
    );

    $wp_customize->add_setting('news_twitter_handle',[
        'default'     => '',
        'sanitize_callback' => 'esc_url_raw'
    ]);

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'news_social_twiiter_input',
        array(
            'label'          => __( 'Twitter Handle', 'news-wp' ),
            'section'        => 'news_social_section',
            'settings'       => 'news_twitter_handle',
            'type'           => 'url'
        )
    )
);

        $wp_customize->add_setting('news_instagram_handle',[
            'default'     => '',
            'sanitize_callback' => 'esc_url_raw'
        ]);

        $wp_customize->add_control(new WP_Customize_Control(
            $wp_customize,
            'news_social_instagram_input',
            array(
                'label'          => __( 'Instagram Handle', 'news-wp' ),
                'section'        => 'news_social_section',
                'settings'       => 'news_instagram_handle',
                'type'           => 'url'
            )
        ));

        $wp_customize->add_setting('news_youtube_handle',[
            'default'     => '',
            'sanitize_callback' => 'esc_url_raw'
        ]);

        $wp_customize->add_control(new WP_Customize_Control(
            $wp_customize,
            'news_youtube_input',
            array(
                'label'          => __( 'YouTube', 'news-wp' ),
                'section'        => 'news_social_section',
                'settings'       => 'news_youtube_handle',
                'type'           => 'url'
            )
        ));

}