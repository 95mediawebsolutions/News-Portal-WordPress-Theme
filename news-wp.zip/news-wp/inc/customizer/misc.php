<?php

function news_misc_customizer_section($wp_customize){
  
    

    $wp_customize->add_section('news_misc_section',[
        'title'     => __('News Misc Settings', 'news-wp'),
        'priority'  => 30,
        'panel'     => 'news_wp'
    ]);
    
    // header section customizer content

    $wp_customize->add_setting('news_header_phone_number',[
        'default'           => 'Enter Phone number or email here',
        'sanitize_callback' => 'news_sanitize_html'
    ]);

$wp_customize->add_control(new WP_Customize_Control(
   $wp_customize,
   'news_header_phone_email_input',
   array(
       'label'          => __( 'Email Goes Here', 'news-wp' ),
       'section'        => 'news_misc_section',
       'settings'       => 'news_header_phone_number',
       'type' 			 => 'text'
      
   )
));


    // end header customizer content
    
    // Checkbox to show activated or deactivated for preloader
       $wp_customize->add_setting('con_preloader',[
        'default'            => 'yes',
        'sanitize_callback'  => 'news_sanitize_checkbox'
        
    ]);
 
 
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_show_preload_input',
        array(
            'label'                 =>  __( 'Activate Preloader', 'news-wp' ),
            'section'               => 'news_misc_section',
            'settings'              => 'con_preloader',
            'type'                  =>  'checkbox',
            'choices'               => [
                'no'               => 'No'
            ],
        )
    ));
    
    // end preloader checkbox
    
    // upload Preloader Image
     $wp_customize->add_setting('news_page_loader_logo', [
        'default'                   => '',
        'sanitize_callback'         => 'news_wp_validate_image'
    ]);

     $wp_customize->add_control(new WP_Customize_Upload_Control(
        $wp_customize,
        'news_preloader_file_input',
        array(
            'label'                 =>  __( 'Upload Preloader Image', 'news-wp' ),
            'section'               => 'news_misc_section',
            'settings'              => 'news_page_loader_logo',
        )
    ));
    // Preloader image customizer function end here
    

// copyright information start here for customizer
    $wp_customize->add_setting('news_footer_copyright_text',[
             'default'           => 'Copyright &copy; 2020 All Rights Reserved.',
             'sanitize_callback' => ''
         ]);

    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'news_footer_copyright_input',
        array(
            'label'          => __( 'CopyRight Information', 'news-wp' ),
            'section'        => 'news_misc_section',
            'settings'       => 'news_footer_copyright_text',
            'type' 			 => 'text'
           
        )
    ));

    // copyright information ends here for customizer.
    
    
     // Show Social Media Icon on front page
     $wp_customize->add_setting('load_social_media',[
        'default'            => 'yes',
        'type' 				 => 'theme_mod',
        'transport'          => 'postMessage',
        'sanitize_callback'  => 'news_sanitize_checkbox'
        
    ]);
 
 
    $wp_customize->add_control(new WP_Customize_Control(
        $wp_customize,
        'con_show_preload_input',
        array(
            'label'                 =>  __( 'Show Social Media on front Page', 'news-wp' ),
            'section'               => 'news_misc_section',
            'settings'              => 'load_social_media',
            'type'                  =>  'checkbox',
            'choices'               => [
                'no'               => 'No'
            ],
        )
    ));
    
    // end social media on front page



        // contact address map information start here for customizer
        $wp_customize->add_setting('contact_address_map',[
            'default'           => '',
            'sanitize_callback' => ''
        ]);
    
    $wp_customize->add_control(new WP_Customize_Control(
       $wp_customize,
       'news_contact_address_map',
       array(
           'label'          => __( 'Contact Address Map', 'news-wp' ),
           'section'        => 'news_misc_section',
           'settings'       => 'contact_address_map',
           'type' 			 => 'textarea'
          
       )
    ));

    // contact address information start here for customizer
    $wp_customize->add_setting('contact_form_information_address',[
        'default'           => 'Enter Your Company Address Here',
        'sanitize_callback' => 'news_sanitize_html'
    ]);

$wp_customize->add_control(new WP_Customize_Control(
   $wp_customize,
   'news_contact_address_input',
   array(
       'label'          => __( 'Contact Address', 'news-wp' ),
       'section'        => 'news_misc_section',
       'settings'       => 'contact_form_information_address',
       'type' 			 => 'text'
      
   )
));

// phone number information ends here for customizer.

    // contact address information start here for customizer
    $wp_customize->add_setting('contact_form_phone_number',[
        'default'           => '+234',
        'sanitize_callback' => 'wp_filter_nohtml_kses'
    ]);

$wp_customize->add_control(new WP_Customize_Control(
   $wp_customize,
   'news_phone_number_input',
   array(
       'label'          => __( 'Contact Phone Number', 'news-wp' ),
       'section'        => 'news_misc_section',
       'settings'       => 'contact_form_phone_number',
       'type' 			 => 'text'
      
   )
));

// contact phone number information ends here for customizer.



// contact email information information ends here for customizer.

  
    $wp_customize->add_setting('contact_email',[
        'default'           => 'support@95media.co.uk',
        'sanitize_callback' => 'sanitize_email'
    ]);

$wp_customize->add_control(new WP_Customize_Control(
   $wp_customize,
   'news_contact_email_input',
   array(
       'label'          => __( 'Contact Email Address', 'news-wp' ),
       'section'        => 'news_misc_section',
       'settings'       => 'contact_email',
       'type' 			 => 'text'
      
   )
));

// contact email information ends here for customizer.
  



}


function news_sanitize_checkbox( $checked ){
    //returns true if checkbox is checked
    return ( ( isset( $checked ) && true == $checked ) ? true : false );
}

function news_sanitize_html( $html ) {
	return wp_filter_post_kses( $html );
}


/**
 * Sanitization: image
 * Control: text, WP_Customize_Image_Control
 *
 * Sanitization callback for images.
 *
 * @uses	news_wp_validate_image()		
 * @uses	esc_url_raw()				http://codex.wordpress.org/Function_Reference/esc_url_raw
 */
function news_wp_sanitize_image( $input, $setting ) {
	return esc_url_raw( theme_slug_validate_image( $input, $setting->default ) );
}

/**
 * Validation: image
 * Control: text, WP_Customize_Image_Control
 *
 * @uses	wp_check_filetype()		https://developer.wordpress.org/reference/functions/wp_check_filetype/
 * @uses	in_array()				http://php.net/manual/en/function.in-array.php
 */
 
function news_wp_validate_image( $input, $default = '' ) {
	// Array of valid image file types
	// The array includes image mime types
	// that are included in wp_get_mime_types()
	$mimes = array(
		'jpg|jpeg|jpe' => 'image/jpeg',
		'gif'          => 'image/gif',
		'png'          => 'image/png',
		'bmp'          => 'image/bmp',
		'tif|tiff'     => 'image/tiff',
		'ico'          => 'image/x-icon'
	);
	// Return an array with file extension
	// and mime_type
	$file = wp_check_filetype( $input, $mimes );
	// If $input has a valid mime_type,
	// return it; otherwise, return
	// the default.
	return ( $file['ext'] ? $input : $default );
}