<?php 

function news_wp_replace_submenu_class($menu) {  
    $menu = preg_replace('/ class="sub-menu"/','/ class="submenu" /',$menu);  
    return $menu;  
  }  
  add_filter('wp_nav_menu','news_wp_replace_submenu_class'); 

  function news_wp_comment_reply_link($content) {
    $extra_classes = 'btn-reply text-uppercase';
    return preg_replace( '/comment-reply-link/', 'comment-reply-link ' . $extra_classes, $content);
}
add_filter('comment_reply_link', 'news_wp_comment_reply_link', 99);

// define the comment_form_submit_button callback
function filter_comment_form_submit_button($submit_button, $args)
{
    // make filter magic happen here...
    $submit_before = '<div class="col-sm-12"><div class="form-group">';
    $submit_after = '</div></div>';
    return $submit_before . $submit_button . $submit_after;
};

// add the filter
add_filter('comment_form_submit_button', 'filter_comment_form_submit_button', 10, 2);

function disable_self_ping( &$links ) {
  foreach ( $links as $l => $link )
  if ( 0 === strpos( $link, home_url() ) )
  unset($links[$l]);
 }
 add_action( 'pre_ping', 'disable_self_ping' );





function as_adapt_comment_form( $arg ) {
    // add Foundation classes to the button class
    $arg['class_submit'] = 'button button-contactForm btn_1 boxed-btn';

    // return the modified array
    return $arg;
}

// run the comment form defaults through the newly defined filter
add_filter( 'comment_form_defaults', 'as_adapt_comment_form' );




  /**
 * Extend Recent Posts Widget 
 *
 * Adds different formatting to the default WordPress Recent Posts Widget
 */

Class News_Recent_Posts_Widget extends WP_Widget_Recent_Posts {

  function widget($args, $instance) {

          if ( ! isset( $args['widget_id'] ) ) {
          $args['widget_id'] = $this->id;
      }

      $title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Recent Posts', 'news-wp' );

      /** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
      $title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

      $number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
      if ( ! $number )
          $number = 5;
      $show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

      /**
       * Filter the arguments for the Recent Posts widget.
       *
       * @since 3.4.0
       *
       * @see WP_Query::get_posts()
       *
       * @param array $args An array of arguments used to retrieve the recent posts.
       */
      $r = new WP_Query( apply_filters( 'widget_posts_args', array(
          'posts_per_page'      => $number,
          'no_found_rows'       => true,
          'post_status'         => 'publish',
          'ignore_sticky_posts' => true
      ) ) );

      if ($r->have_posts()) :
      ?>
      <?php echo $args['before_widget']; ?>
      <?php if ( $title ) {
          echo $args['before_title'] . $title . $args['after_title'];
      } ?>
     
      <?php while ( $r->have_posts() ) : $r->the_post(); 
        $recent_post_image = get_the_post_thumbnail_url(get_the_ID(),'widget_recent_post');
       ?>
           <div class="media post_item">
          <?php if(!empty($recent_post_image)) : ?>

              <img src="<?php echo $recent_post_image; ?>">
              <?php else:?>
              <img src="https://place-hold.it/200x200">
              <?php endif?>
                        <div class="media-body">
                           <a href="<?php the_permalink();?>">
                              <h3><?php the_title();?></h3>
                           </a>
                           <p><?php echo esc_html(get_the_date()); ?></p>
                        </div>
                     </div>

         

      <?php endwhile; ?>
     
      <?php echo $args['after_widget']; ?>
      <?php
      // Reset the global $the_post as this query will have stomped on it
      wp_reset_postdata();

      endif;
  }
}
function news_recent_widget_registration() {
unregister_widget('WP_Widget_Recent_Posts');
register_widget('News_Recent_Posts_Widget');
}
add_action('widgets_init', 'news_recent_widget_registration');



// Custom widget

/*
	Footer Popular Posts Widget with image
*/

class News_WP_Footer_Popular_Posts_Widget extends WP_Widget {
	
	//setup the widget name, description, etc...
	public function __construct() {
		
		$widget_ops = array(
			'classname' => 'news-wp-footer-popular-posts-widget',
			'description' => 'Footer Popular Widgets',
		);
		parent::__construct( 'news_wp_footer_popular_posts', 'Footer Popular Widgets with image', $widget_ops );
		
	}
	
	// back-end display of widget
	public function form( $instance ) {
		
		$title = ( !empty( $instance[ 'title' ] ) ? $instance[ 'title' ] : 'Popular Posts' );
		$tot = ( !empty( $instance[ 'tot' ] ) ? absint( $instance[ 'tot' ] ) : 4 );
		
		$output = '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'title' ) ) . '">Title:</label>';
		$output .= '<input type="text" class="widefat" id="' . esc_attr( $this->get_field_id( 'title' ) ) . '" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" value="' . esc_attr( $title ) . '"';
		$output .= '</p>';
		
		$output .= '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'tot' ) ) . '">Number of Posts:</label>';
		$output .= '<input type="number" class="widefat" id="' . esc_attr( $this->get_field_id( 'tot' ) ) . '" name="' . esc_attr( $this->get_field_name( 'tot' ) ) . '" value="' . esc_attr( $tot ) . '"';
		$output .= '</p>';
		
		echo $output;
		
	}
	
	// update widget
	public function update( $new_instance, $old_instance ) {
		
		$instance = array();
		$instance[ 'title' ] = ( !empty( $new_instance[ 'title' ] ) ? strip_tags( $new_instance[ 'title' ] ) : '' );
		$instance[ 'tot' ] = ( !empty( $new_instance[ 'tot' ] ) ? absint( strip_tags( $new_instance[ 'tot' ] ) ) : 0 );
		
		return $instance;
		
	}
	
	// front-end display of widget
	public function widget( $args, $instance ) {
		
		$tot = absint( $instance[ 'tot' ] );
		
		$posts_args = array(
			'post_type'			=> 'post',
			'posts_per_page'	=> $tot,
			'orderby'			=> 'meta_value_num',
			'order'				=> 'DESC'
		);
		
		$posts_query = new WP_Query( $posts_args );
		
		echo $args[ 'before_widget' ];
		
		if( !empty( $instance[ 'title' ] ) ):
			
			echo $args[ 'before_title' ] . apply_filters( 'widget_title', $instance[ 'title' ] ) . $args[ 'after_title' ];
			
		endif;
		
		if( $posts_query->have_posts() ):	while( $posts_query->have_posts() ): $posts_query->the_post(); ?>
				
        <div class="whats-right-single mb-20">
                              <div class="whats-right-img">
                                 <?php the_post_thumbnail('widget_recent_post');?>
                              </div>
                              <div class="whats-right-cap">
                                 <h4><a href="<?php the_permalink();?>"><?php the_title()?></a></h4>
                                 <p><?php the_author();?>  |  <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></p> 
                              </div>
                        </div>
				
		<?php	endwhile;
				
			//echo '</ul>';
		
		endif;
		
		echo $args[ 'after_widget' ];
		
	}
	
}

add_action( 'widgets_init', function() {
	register_widget( 'News_WP_Footer_Popular_Posts_Widget' );
} );


// Social media widget


class Media_Social_Profile extends WP_Widget {

  /**
   * Register widget with WordPress.
   */

   
  function __construct() {
      parent::__construct(
              'Media_Social_Profile',
              __('Social Networks Profile', 'news-wp'), // Name
              array('description' => __('Links to Author social media profile', 'news-wp'),)
      );
  }

  /**
   * Front-end display of widget.
   *
   * @see WP_Widget::widget()
   *
   * @param array $args     Widget arguments.
   * @param array $instance Saved values from database.
   */
  public function widget($args, $instance) {

    
      $title = apply_filters('widget_title', $instance['title']);
      $facebook = $instance['facebook'];
      $twitter = $instance['twitter'];
      $instagram = $instance['instagram'];
      $linkedin = $instance['linkedin'];

      // social profile link
      $facebook_profile = '<a class="facebook" href="' . $facebook . '"><i class="fab fa-facebook-f"></i></a>';
      $twitter_profile = '<a class="twitter" href="' . $twitter . '"><i class="fab fa-twitter"></i></a>';
      $instagram_profile = '<a class="instagram" href="' . $instagram . '"><i class="fab fa-instagram"></i></a>';
      $linkedin_profile = '<a class="linkedin" href="' . $linkedin . '"><i class="fab fa-linkedin"></i></a>';

      echo $args['before_widget'];

      if (!empty($title)) {
          echo $args['before_title'] . $title . $args['after_title'];
      }

      echo '<div class="social-icons">';
      echo (!empty($facebook) ) ? $facebook_profile : null;
      echo (!empty($twitter) ) ? $twitter_profile : null;
      echo (!empty($instagram) ) ? $instagram_profile : null;
      echo (!empty($linkedin) ) ? $linkedin_profile : null;
      echo '</div>';
      

      echo $args['after_widget'];
  }

  /**
   * Back-end widget form.
   *
   * @see WP_Widget::form()
   *
   * @param array $instance Previously saved values from database.
   */
  public function form($instance) {
      isset($instance['title']) ? $title = $instance['title'] : null;
      empty($instance['title']) ? $title = '' : null;
      $facebook = null; $twitter = null; $instagram = null; $linkedin = null;

      isset($instance['facebook']) ? $facebook = $instance['facebook'] : null;
      isset($instance['twitter']) ? $twitter = $instance['twitter'] : null;
      isset($instance['instagram']) ? $instagram = $instance['instagram'] : null;
      isset($instance['linkedin']) ? $linkedin = $instance['linkedin'] : null;
      ?>
      <p>
          <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:', 'news-wp'); ?></label> 
          <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>">
      </p>

      <p>
          <label for="<?php echo $this->get_field_id('facebook'); ?>"><?php _e('Facebook:', 'news-wp'); ?></label> 
          <input class="widefat" id="<?php echo esc_attr($this->get_field_id('facebook')); ?>" name="<?php echo esc_attr($this->get_field_name('facebook')); ?>" type="text" value="<?php echo esc_attr($facebook); ?>">
      </p>

      <p>
          <label for="<?php echo $this->get_field_id('twitter'); ?>"><?php _e('Twitter:', 'news-wp'); ?></label> 
          <input class="widefat" id="<?php echo $this->get_field_id('twitter'); ?>" name="<?php echo $this->get_field_name('twitter'); ?>" type="text" value="<?php echo esc_attr($twitter); ?>">
      </p>

      <p>
          <label for="<?php echo $this->get_field_id('instagram'); ?>"><?php _e('Instagram:', 'news-wp'); ?></label> 
          <input class="widefat" id="<?php echo $this->get_field_id('instagram'); ?>" name="<?php echo $this->get_field_name('instagram'); ?>" type="text" value="<?php echo esc_attr($instagram); ?>">
      </p>

      <p>
          <label for="<?php echo $this->get_field_id('linkedin'); ?>"><?php _e('Linkedin:', 'news-wp'); ?></label> 
          <input class="widefat" id="<?php echo $this->get_field_id('linkedin'); ?>" name="<?php echo $this->get_field_name('linkedin'); ?>" type="text" value="<?php echo esc_attr($linkedin); ?>">
      </p>

      <?php
  }

  /**
   * Sanitize widget form values as they are saved.
   *
   * @see WP_Widget::update()
   *
   * @param array $new_instance Values just sent to be saved.
   * @param array $old_instance Previously saved values from database.
   *
   * @return array Updated safe values to be saved.
   */
  public function update($new_instance, $old_instance) {
      $instance = array();
      $instance['title'] = (!empty($new_instance['title']) ) ? strip_tags($new_instance['title']) : '';
      $instance['facebook'] = (!empty($new_instance['facebook']) ) ? strip_tags($new_instance['facebook']) : '';
      $instance['twitter'] = (!empty($new_instance['twitter']) ) ? strip_tags($new_instance['twitter']) : '';
      $instance['instagram'] = (!empty($new_instance['instagram']) ) ? strip_tags($new_instance['instagram']) : '';
      $instance['linkedin'] = (!empty($new_instance['linkedin']) ) ? strip_tags($new_instance['linkedin']) : '';

      return $instance;
  }

}



// register Media_Social_Profile widget
function register_media_social_profile() {
  register_widget('Media_Social_Profile');
}

add_action('widgets_init', 'register_media_social_profile');

// Custom widget

/*
	Home Popular Posts Widget with image
*/

class News_WP_Home_Popular_Posts_Widget extends WP_Widget {
	
	//setup the widget name, description, etc...
	public function __construct() {
		
		$widget_ops = array(
			'classname' => 'news-wp-home-popular-posts-widget',
			'description' => 'Home Popular Widgets',
		);
		parent::__construct( 'news_wp_home_popular_posts', 'Home Popular Widgets with image', $widget_ops );
		
	}
	
	// back-end display of widget
	public function form( $instance ) {
		
		// $title = ( !empty( $instance[ 'title' ] ) ? $instance[ 'title' ] : 'Popular Posts' );
		$tot = ( !empty( $instance[ 'tot' ] ) ? absint( $instance[ 'tot' ] ) : 4 );
		
		$output = '';

		
		$output .= '<p>';
		$output .= '<label for="' . esc_attr( $this->get_field_id( 'tot' ) ) . '">Number of Posts:</label>';
		$output .= '<input type="number" class="widefat" id="' . esc_attr( $this->get_field_id( 'tot' ) ) . '" name="' . esc_attr( $this->get_field_name( 'tot' ) ) . '" value="' . esc_attr( $tot ) . '"';
		$output .= '</p>';
		
		echo $output;
		
	}
	
	// update widget
	public function update( $new_instance, $old_instance ) {
		
		$instance = array();
		$instance[ 'title' ] = ( !empty( $new_instance[ 'title' ] ) ? strip_tags( $new_instance[ 'title' ] ) : '' );
		$instance[ 'tot' ] = ( !empty( $new_instance[ 'tot' ] ) ? absint( strip_tags( $new_instance[ 'tot' ] ) ) : 0 );
		
		return $instance;
		
	}
	
	// front-end display of widget
	public function widget( $args, $instance ) {
		
		$tot = absint( $instance[ 'tot' ] );
		
		$posts_args = array(
			'post_type'			=> 'post',
			'posts_per_page'	=> $tot,
			'orderby'			=> 'meta_value_num',
			'order'				=> 'DESC'
		);
		
		$posts_query = new WP_Query( $posts_args );
		
		echo $args[ 'before_widget' ];
		
		if( !empty( $instance[ 'title' ] ) ):
			
			echo $args[ 'before_title' ] . apply_filters( 'widget_title', $instance[ 'title' ] ) . $args[ 'after_title' ];
			
		endif;
		
		if( $posts_query->have_posts() ):	while( $posts_query->have_posts() ): $posts_query->the_post(); ?>
      
      <div class="trending-top mb-30">
            <div class="trend-top-img">
               <?php the_post_thumbnail('trending-top-post')?>
                <div class="trend-top-cap trend-top-cap2">
                    <span class="bgg"><?php the_category();?> </span>
                    <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
                    <p>by <?php the_author();?>   -   <?php echo esc_html(get_the_date()); ?></p>
                </div>
            </div>
        </div>
       
		<?php	endwhile;
				
			//echo '</ul>';
		
		endif;
		
		echo $args[ 'after_widget' ];
		
	}
	
}

add_action( 'widgets_init', function() {
	register_widget( 'News_WP_Home_Popular_Posts_Widget' );
} );



add_filter( 'wpcf7_form_class_attr', 'custom_custom_form_class_attr' );

function custom_custom_form_class_attr( $class ) {
  $class .= ' form-contact contact_form';
  return $class;
}