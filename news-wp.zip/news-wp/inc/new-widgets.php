<?php

function news_widgets(){

register_sidebar([
    'name'          => __('Blog Sidebar', 'news-wp'),
    'id'            => 'blog_sidebar',
    'description'   => __('Blog sidebar for news-wp', 'news-wp'),
    'before_widget' => '<aside id="%1$s" class="single_sidebar_widget widget %2$s">',
    'after_widget'  => '</aside>',
    'class'         => 'nav-list',
    'before_title'  => '<h4 class="widget_title">',
    'after_title'   => '</h4>'
]);

register_sidebar([
    'name'          => __('Header Sidebar', 'news-wp'),
    'id'            => 'news_header_widget_ads',
    'description'   => __('Header Widgets for News Banner', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
]);

register_sidebar([
    'name'          => __('Home Widget Section', 'news-wp'),
    'id'            => 'home_post_widget',
    'description'   => __('Home widgets for news-wp', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets" %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
]);


register_sidebar([
    'name'          => __('Left Sidebar Ads Widgets', 'news-wp'),
    'id'            => 'news_sidebar_widget_ads',
    'description'   => __('sidebar Ads Widgets for News Banner', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
]);


register_sidebar([
    'name'          => __('Ads Section Before Footer Widget', 'news-wp'),
    'id'            => 'news_ads_section_b4_footer_widget_ads',
    'description'   => __('Ads Section Before Footer Widget', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
]);


register_sidebar([
    'name'          => __('Footer Widgets 1', 'news-wp'),
    'id'            => 'footer_widgets_1',
    'description'   => __('Footer widgets for news-wp', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets" %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
]);


register_sidebar([
    'name'          => __('Footer Widgets 2', 'news-wp'),
    'id'            => 'footer_widgets_2',
    'description'   => __('Footer widgets for news-wp', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets" %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<div class="footer-tittle"><h4>',
    'after_title'   => '</h4></div>'
]);

register_sidebar([
    'name'          => __('Footer Widgets 3', 'news-wp'),
    'id'            => 'footer_widgets_3',
    'description'   => __('Footer widgets for news-wp', 'news-wp'),
    'before_widget' => '<div id="%1$s" class="widgets" %2$s">',
    'after_widget'  => '</div>',
    'before_title'  => '<h4>',
    'after_title'   => '</h4>'
]);

}