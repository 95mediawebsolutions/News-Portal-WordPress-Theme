<?php

function news_setup_theme_files(){

    add_theme_support('post-thumbnails');
    add_theme_support('title-tag');
    add_theme_support('automatic-feed-links');
    add_theme_support('custom-logo');
    add_theme_support('html5', array('comment-list', 'comment-form', 'search-form', 'gallery', 'caption'));

    add_image_size('slider-blog-post', 770, 662, array('center', 'center'));
    add_image_size('most-popular-post', 245, 162, array('center', 'center'));
    add_image_size('trending-post', 365, 290, array('center', 'center'));
    add_image_size('weekly-news', 270, 216, array('center', 'center'));
    add_image_size('blog-post', 770, 385, array('center', 'center'));
    add_image_size('widget_recent_post', 80, 80, array('center', 'center'));
    add_image_size('trending-post', 381, 290, array('center', 'center'));
    add_image_size('trending-top-post', 381, 200, array('center', 'center'));
    add_image_size('most-recent-sidebar-post', 85, 79, array('center', 'center'));
  

    register_nav_menu('primary', __('Primary Menu', 'news-wp'));
    

    if(is_singular() && comments_open() && get_option('thread_comments')){
        wp_enqueue_script('comment_reply');
    }

    if(!isset($content_width)){
        $content_width = 900;
    }

}

