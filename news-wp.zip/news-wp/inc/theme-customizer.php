<?php 

function news_customize_register($wp_customize){

    $wp_customize->add_panel('news_wp', [
        'title'             => __('News Theme Settings', 'news-wp'),
        'description'       =>  '<p>News Theme Settings</p>',
        'priority'          => 160
    ]);

    news_social_customizer_section($wp_customize);
    news_misc_customizer_section($wp_customize);
}
