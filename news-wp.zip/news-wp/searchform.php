
<?php $unique_id = esc_attr(uniqid());?>

    <form action="<?php echo esc_url(home_url('/'));?>" method="get">
        <div class="form-group">
            <div class="input-group mb-3">
            <input type="text" class="form-control" name="s" id="<?php echo $unique_id; ?>"
        placeholder='<?php _e( 'Search News Theme', 'news-wp' ); ?>'
        <div class="input-group-append">
                <div class="input-group-append">
                    <button class="btns" type="submit"><i class="ti-search"></i></button>
                </div>
            </div>
        </div>
        <button class="button rounded-0 primary-bg text-white w-100 btn_1 boxed-btn"
            type="submit">Search</button>
    </form>