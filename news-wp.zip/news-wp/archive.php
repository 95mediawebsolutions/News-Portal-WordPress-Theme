<?php get_header();?>

<!--================Blog Area =================-->
<section class="blog_area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <div class="blog_left_sidebar">
                        <?php if(have_posts()):?>
                        <?php while(have_posts()): the_post()?>
                        <?php get_template_part( 'template-parts/content-archive' );?>
                        <?php endwhile; endif;?>
                        <nav class="blog-pagination justify-content-center d-flex">
                            <ul class="pagination">
                                <?php the_posts_pagination(array(
                                       'prev_text' => esc_html__('Previous', 'news-wp'),
                                       'next_text' => esc_html__('Next', 'news-wp')
                                   ))?>

                            </ul>
                        </nav>
                    </div>
                </div>
                <?php get_sidebar();?>
            </div>
        </div>
    </section>
    <!--================Blog Area =================-->

<?php get_footer();?>