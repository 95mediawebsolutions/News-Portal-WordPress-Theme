News Portal is a free html theme from colorlib.com converted to Wordpress theme by 95media

Html Template link: https://colorlib.com/preview/theme/news/

The Theme is a mini news portal website, bootstrap ready, and with such as custom logo, custom widgets, social media widgets, Blog section, widgets ads sections and many more.
i purposely did not add the Whats New section to the theme as a plan to have that added as an update and also the next update will be gutenberg read as well.

How to install the theme.

1. Download the theme from https://www.95media.co.uk/free-theme/news-wordpress-theme/

2. Upload the download theme to your Wordpress website

3. Install the necessary extensions after activating the theme

4. Install the following plugin to for the demos

4.1 - Widget Importer & Exporter 
4.2 - Customizer Export/Import 

5. News Portal Wordpress Theme is ready for use

Preview Theme: https://news.95media.co.uk

Kindly let me know to make the theme better.

Thank you.