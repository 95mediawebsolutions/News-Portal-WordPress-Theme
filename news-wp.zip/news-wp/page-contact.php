<?php // Template Name: Contact Page

get_header();
?>



  <!-- ================ contact section start ================= -->
  <section class="contact-section">
    <div class="container">
       
        <div class="d-none d-sm-block mb-5 pb-4">

        <?php echo get_theme_mod('contact_address_map');?>

        </div>
        

        <div class="row">
            <div class="col-12">
                <h2 class="contact-title"><?php _e('Get in Touch', 'news-wp');?></h2>
            </div>
            <?php while( have_posts() ): the_post();?>
            <div class="col-lg-8">
                <?php the_content();?>
            </div>
        <?php endwhile;?>
            
            <div class="col-lg-3 offset-lg-1">
                <?php if(get_theme_mod('contact_form_information_address')):?>
                <div class="media contact-info">
                    <span class="contact-info__icon"><i class="ti-home"></i></span>
                    <div class="media-body">
                        <p><?php echo esc_html(get_theme_mod('contact_form_information_address'));?></p>
                      
                    </div>
                </div>
                <?php endif;?>
                <?php if(get_theme_mod('contact_form_phone_number')):?>
                <div class="media contact-info">
                    <span class="contact-info__icon"><i class="ti-tablet"></i></span>
                    <div class="media-body">
                        <h3><?php echo esc_html(get_theme_mod('contact_form_phone_number'));?></h3>
                        <p><?php _e('Mon to Fri 9am to 6pm', 'news-wp')?></p>
                    </div>
                </div>
                <?php endif;?>
                <?php if(get_theme_mod('contact_email')):?>
                <div class="media contact-info">
                    <span class="contact-info__icon"><i class="ti-email"></i></span>
                    <div class="media-body">
                        <h3><?php echo esc_html(get_theme_mod('contact_email'));?></h3>
                        <p><?php _e('Send us your query anytime!', 'news-wp');?></p>
                    </div>
                </div>
                <?php endif;?>
            </div>
        </div>
    </div>
    </section>
    <!-- ================ contact section end ================= -->


<?php get_footer();?>