<!doctype html>
<html class="no-js" lang="<?php language_attributes();?>">
<head>
    <meta charset="<?php bloginfo('charset');?>">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head();?>
</head>

<body <?php body_class();?>>
<?php wp_body_open(); ?>
<!-- Preloader Start -->
<?php if(get_theme_mod('news_preloader')):?>
<div id="preloader-active">
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-inner position-relative">
            <div class="preloader-circle"></div>
            <div class="preloader-img pere-text">
                <img src="<?php echo esc_url_raw(get_theme_mod('news_page_loader_logo'));?>" alt="<?php bloginfo('name');?>">
            </div>
        </div>
    </div>
</div>
<?php endif;?>
<!-- Preloader Start -->
<header>
    <!-- Header Start -->
    <div class="header-area">
        <div class="main-header ">
            <div class="header-top black-bg d-none d-sm-block">
                <div class="container">
                    <div class="col-xl-12">
                        <div class="row d-flex justify-content-between align-items-center">
                            <!--<div class="header-info-left">-->
                            <!--    <ul>     -->
                            <!--        <li class="title"><span class="flaticon-energy"></span> trending-title</li>-->
                            <!--        <li>Class property employ ancho red multi level mansion</li>-->
                            <!--    </ul>-->
                            <!--</div>-->
                            <?php if(get_theme_mod('news_header_phone_number')):?>
                            <div class="header-info-right">
                                <ul class="header-date">
                                    <li><?php echo get_theme_mod('news_header_phone_number');?></li>
                                </ul>
                            </div>
                            <?php endif;?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-mid gray-bg">
                <div class="container">
                    <div class="row d-flex align-items-center">
                        <!-- Logo -->
                        <div class="col-xl-3 col-lg-3 col-md-3 d-none d-md-block">
                            <div class="logo">
                                <?php if(has_custom_logo()):?>
                                    <?php the_custom_logo()?>
                                <?php else:?>
                                <a href="<?php echo esc_url(home_url('/'));?>"><h2 class="medium"><?php bloginfo('name');?></h2></a>
                                <?php endif;?>
                            </div>
                        </div>
                        <div class="col-xl-9 col-lg-9 col-md-9">
                            <div class="header-banner f-right ">
                            <?php if(is_active_sidebar('news_header_widget_ads')){
                                 dynamic_sidebar('news_header_widget_ads');
                                     }?>            
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="header-bottom header-sticky">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-8 col-lg-8 col-md-12 header-flex">
                            <!-- sticky -->
                            <div class="sticky-logo">
                            <?php if(has_custom_logo()):?>
                                    <?php the_custom_logo()?>
                            <?php endif;?>
                            </div>
                            <!-- Main-menu -->
                            <div class="main-menu d-none d-md-block">
                                <nav>                 
                                    <?php if(has_nav_menu('primary')){
                                       wp_nav_menu(array(
                                        'theme_location'  => 'primary',
                                        'depth'           => 2,
                                        'menu_id'         => 'navigation',
                                       ));
                                   }?>
                                </nav>
                            </div>
                        </div>             
                        <div class="col-xl-4 col-lg-4 col-md-4">
                            <div class="header-right f-right d-none d-lg-block">
                                <!-- Heder social -->
                                <ul class="header-social">   
                                    <?php if(get_theme_mod('news_facebook_handle')):?> 
                                    <li><a href="<?php echo esc_url(get_theme_mod('news_facebook_handle'));?>"><i class="fab fa-facebook-f"></i></a></li>
                                    <?php endif;?>
                                    <?php if (get_theme_mod('news_twitter_handle')):?>
                                    <li><a href="<?php echo esc_url(get_theme_mod('news_twitter_handle'));?>"><i class="fab fa-twitter"></i></a></li>
                                    <?php endif;?>
                                    <?php if(get_theme_mod('news_instagram_handle')):?>
                                    <li><a href="<?php echo esc_url(get_theme_mod('news_instagram_handle'));?>"><i class="fab fa-instagram"></i></a></li>
                                    <?php endif;?>
                                    <?php if(get_theme_mod('news_youtube_handle')):?>
                                    <li> <a href="<?php echo esc_url(get_theme_mod('news_youtube_handle'));?>"><i class="fab fa-youtube"></i></a></li>
                                    <?php endif;?>
                                </ul>
                                <!-- Search Nav -->
                                <div class="nav-search search-switch">
                                    <i class="fa fa-search"></i>
                                </div>
                            </div>
                        </div>
                        <!-- Mobile Menu -->
                        <div class="col-12">
                            <div class="mobile_menu d-block d-md-none"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->
</header>
<main>