<?php get_header();?>

 <!--================Blog Area =================-->
 <section class="blog_area single-post-area section-padding">
      <div class="container">
         <div class="row">
            <div <?php post_class( 'col-lg-8 posts-list' ); ?> id="post-<?php the_ID(); ?>">
            <?php while (have_posts()): the_post(); global $post;?>
               <div class="single-post">
                  <div class="feature-img">
                  <?php the_post_thumbnail('blog-post', array('class' => 'img-fluid'));?>
                  </div>
                  <div class="blog_details">
                     <h2><?php the_title();?></h2>
                     <ul class="blog-info-link mt-3 mb-4">
                     <li><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><i class="fa fa-user"></i> <?php the_author();?>  &nbsp; |  &nbsp; <?php the_category(',')?></a></li>
                        <li><a href="<?php echo get_comments_link();?>"><i class="fa fa-comments"></i> <?php comments_number('0');?></a></li>
                     </ul>
                     
                    <?php the_content();?>
                
                  </div>
               </div>
            
               <div class="navigation-top">
                
                  <div class="navigation-area">
                     <div class="row">
                        <div class="col-lg-6 col-md-6 col-12 nav-left flex-row d-flex justify-content-start align-items-center">
                           <div class="detials">
                              <p>Prev Post</p>
                              <?php previous_post_link();?>
                           </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12 nav-right flex-row d-flex justify-content-end align-items-center">
                           <div class="detials">
                              <p>Next Post</p>
                              <?php next_post_link();?>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="blog-author">
                  <div class="media align-items-center">
                  <?php echo get_avatar(get_author_posts_url($post->post_author), 90, '', false, array('class' => 'img-circle'));?>
                     <div class="media-body">
                        <a href="<?php echo get_author_posts_url($post->post_author);?>">
                           <h4><?php the_author();?></h4>
                        </a>
                        <p><?php echo nl2br(get_the_author_meta('description'));?></p>
                     </div>
                  </div>
               </div>
               <?php endwhile;?>
              
               <?php if(comments_open() || get_comments_number()){
                 comments_template();
             }?>

            </div> <!-- end col-lg-8 -->
            
            <?php get_sidebar();?>
           
           
            <!-- end col-lg-4 -->
         </div>
           
      </div>
   </section>
   <!--================ Blog Area end =================-->


      


<?php get_footer();?>