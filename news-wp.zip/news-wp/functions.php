<?php

include(get_theme_file_path('inc/news-enqueue.php'));
include(get_theme_file_path('inc/news-setup.php'));
include(get_theme_file_path('inc/extra-functions.php'));
include(get_theme_file_path('inc/new-widgets.php'));
include(get_theme_file_path('inc/theme-customizer.php'));
include(get_theme_file_path('inc/customizer/social.php'));
include(get_theme_file_path('inc/customizer/misc.php'));

require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';
require_once get_template_directory() . '/inc/required-plugins.php';

add_action('wp_enqueue_scripts', 'news_enqueue');
add_action('after_setup_theme', 'news_setup_theme_files');
add_action('widgets_init', 'news_widgets');
add_action('customize_register', 'news_customize_register');