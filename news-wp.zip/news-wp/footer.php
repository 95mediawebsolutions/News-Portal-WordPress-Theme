</main>
<footer>
    <!-- Footer Start-->
    <div class="footer-main footer-bg">
        <div class="footer-area footer-padding">
            <div class="container">
                <div class="row d-flex justify-content-between">
                <div class="col-xl-3 col-lg-3 col-md-5 col-sm-8">
                        <div class="single-footer-caption mb-50">
                            <div class="single-footer-caption mb-30">

                        <?php if(is_active_sidebar('footer_widgets_1')){
                                 dynamic_sidebar('footer_widgets_1');
                        }?>
                    </div>
                    </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-5 col-sm-7">
                        <div class="single-footer-caption mb-50">
                        <?php if(is_active_sidebar('footer_widgets_2')){
                                 dynamic_sidebar('footer_widgets_2');
                        }?>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-5 col-sm-7">
                        <div class="single-footer-caption mb-50">
                            <div class="banner">
                            <?php if(is_active_sidebar('footer_widgets_3')){
                                 dynamic_sidebar('footer_widgets_3');
                            }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- footer-bottom aera -->
        <div class="footer-bottom-area footer-bg">
            <div class="container">
                <div class="footer-border">
                    <div class="row d-flex align-items-center">
                        <div class="col-xl-12 ">
                            <div class="footer-copy-right text-center">
                                <p><?php echo esc_html(get_theme_mod('news_footer_copyright_text'));?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
</footer>
<?php $unique_id = esc_attr(uniqid());?>
<!-- Search model Begin -->
<div class="search-model-box">
    <div class="d-flex align-items-center h-100 justify-content-center">
        <div class="search-close-btn">+</div>
        <form class="search-model-form" action="<?php echo esc_url(home_url('/'));?>" method="get">
            <input type="text" id="search-input <?php echo $unique_id;?>" placeholder="Searching key....." name="s">
        </form>
    </div>
</div>
<!-- Search model end -->
<?php wp_footer();?>

</body>
</html>