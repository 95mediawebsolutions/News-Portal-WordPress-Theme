<div class="col-lg-4">
    <div class="blog_right_sidebar">
    <?php if (is_active_sidebar('blog_sidebar')) {
        dynamic_sidebar('blog_sidebar');
    }?>
    </div>
</div>