<div class="single-post">
                  <div class="feature-img">
                     <?php the_post_thumbnail('blog-post', array('class' => 'img-fluid'));?>
                  </div>
                  <div class="blog_details">
                     <h2><?php the_title();?></h2>
                     <ul class="blog-info-link mt-3 mb-4">
                     <li><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><i class="fa fa-user"></i> 
                                        <?php the_author();?>  &nbsp; |  &nbsp; <?php the_category(',')?>
                                    </a>
                                </li>
                                <li><a href="<?php echo get_comments_link();?>"><i class="fa fa-comments"></i> <?php comments_number('0');?></a>
                                </li>
                     </ul>
                     <?php the_content();?>
           
                  </div>
               </div>