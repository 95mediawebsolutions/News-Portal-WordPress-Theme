<article class="blog_item">
    <div class="blog_item_img">
        <?php the_post_thumbnail('blog-post', array('class' => 'card-img rounded-0'));?>
        <a href="#" class="blog_item_date">
            <h3><?php echo esc_html(get_the_date('d'));?></h3>
            <p><?php echo esc_html(get_the_date('M'));?></p>
        </a>
    </div>
    <div class="blog_details">
        <a class="d-inline-block" href="<?php the_permalink();?>">
            <h2><?php the_title();?></h2>
        </a>
        <p><?php the_excerpt();?></p>
        <ul class="blog-info-link">
        <li><a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ); ?>"><i class="fa fa-user"></i> 
                <?php the_author();?>  &nbsp; |  &nbsp; <?php the_category(',')?>
            </a>
        </li>
        <li><a href="<?php echo get_comments_link();?>"><i class="fa fa-comments"></i> <?php comments_number('0');?></a>
        </li>
        </ul>
    </div>
</article>