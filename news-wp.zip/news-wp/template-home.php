<?php get_header();
// Template Name: Blog Home Page With Slider
?>


            <?php $args = array(
                   'posts_per_page' => -1,
                   'post_type' => 'post',
                   'order_by' => 'desc'
			);?>
			

    <!-- Trending Area Start -->
    <div class="trending-area fix pt-25 gray-bg">
        <div class="container">
            <div class="trending-main">
                <div class="row">
                    <div class="col-lg-8">
                        <!-- Trending Top -->
                        <div class="slider-active">
             <?php $slider_post = new WP_Query($args); while($slider_post->have_posts()) : $slider_post->the_post(); ?> 
            <!-- Single -->
            <div class="single-slider">
                <div class="trending-top mb-30">
                    <div class="trend-top-img">
                        <?php the_post_thumbnail('slider-blog-post', array('class' => 'img-fluid'));?>
                        <div class="trend-top-cap">
                            <span class="bgr" data-animation="fadeInUp" data-delay=".2s" data-duration="1000ms"><?php the_category();?></span>
                            <h2><a href="<?php the_permalink();?>" data-animation="fadeInUp" data-delay=".4s" data-duration="1000ms"><?php the_title();?></a></h2>
                            <p data-animation="fadeInUp" data-delay=".6s" data-duration="1000ms">By: <?php the_author();?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); ?>
                        </div>
                    </div>
                    <!-- Right content -->
                    <div class="col-lg-4">
                            <!-- Trending Top -->
                        <div class="row">
                            <div class="col-lg-12 col-md-6 col-sm-6">
                            <?php if(is_active_sidebar('home_post_widget')){
                                 dynamic_sidebar('home_post_widget');
                        }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Trending Area End -->


        <!--   Weekly2-News start -->
        <div class="weekly2-news-area pt-50 pb-30 gray-bg">
        <div class="container">
            <div class="weekly2-wrapper">
                <div class="row">
                    <!-- Banner -->
                    <div class="col-lg-3">
                        <div class="home-banner2 d-none d-lg-block">
                        <?php if(is_active_sidebar('news_sidebar_widget_ads')){
                                 dynamic_sidebar('news_sidebar_widget_ads');
                        }?>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <div class="slider-wrapper">
                            <!-- section Tittle -->
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="small-tittle mb-30">
                                        <h4><?php _e('Most Popular', 'news-wp')?></h4>
                                    </div>
                                </div>
                            </div>
                            <!-- Slider -->
                            <div class="row">
                                <div class="col-lg-12">
                                
                                    <div class="weekly2-news-active d-flex">

                            <?php $args = array(
                                'posts_per_page' => 5,
                                'post_type' => 'post',
                                'orderby' => 'ASC'
                            );?>

                            <?php $most_popular = new WP_Query($args); while($most_popular->have_posts()) : $most_popular->the_post(); ?>
                                        <!-- Single -->
                                        <div class="weekly2-single">

                                            <div class="weekly2-img">
                                                <?php the_post_thumbnail('most-popular-post', array('class' => img-fluid));?>
                                            </div>
                                            <div class="weekly2-caption">
                                                <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4>
                                                <p><?php the_author();?>  |   <?php echo human_time_diff(get_the_time('U'), current_time('timestamp')) . ' ago'; ?></p>
                                            </div>
                                           
                                        </div> 
                                        <?php endwhile; wp_reset_postdata();?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>           
    <!-- End Weekly-News -->

      <!--  Recent Articles start -->
      <div class="recent-articles pt-80 pb-80">
        <div class="container">
            <div class="recent-wrapper">
                <!-- section Tittle -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-tittle mb-30">
                            <h3><?php _e('Trending News', 'news-wp')?></h3>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="recent-active dot-style d-flex dot-style">
                            <!-- Single -->

                            <?php $args = array(
                                'posts_per_page' => 4,
                                'post_type' => 'post',
                                'orderby' => 'ASC'
                            );?>

                            <?php $recent_active = new WP_Query($args); while($recent_active->have_posts()) : $recent_active->the_post(); ?>
                            <div class="single-recent">
                                <div class="what-img">
                                <?php the_post_thumbnail('trending-post', array('class' => 'img-fluid'));?>
                                </div>
                                <div class="what-cap">
                                    <h4><a href="<?php the_permalink();?>" > <h4><a href="<?php the_permalink();?>"><?php the_title();?></a></h4></a></h4>
                                    <P><?php echo get_the_date('M d Y')?></P>
                                    <!-- <span class="fas fa-fire-alt"></span> -->
                                    <i class="fas fa-fire-alt"></i>
                                </div>
                            </div>
                        <?php endwhile; wp_reset_postdata();?>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 


     <!--   Weekly3-News start -->
     <div class="weekly3-news-area pt-80 pb-130">
        <div class="container">
            <div class="weekly3-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="slider-wrapper">
                            <!-- Slider -->
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="weekly3-news-active dot-style d-flex">

                                    <?php $args = array(
                                    'posts_per_page' => -1,
                                    'post_type' => 'post',
                                    'orderby' => 'ASC'
                                    );?>
                        <?php $weekly_news = new WP_Query($args); while($weekly_news->have_posts()) : $weekly_news->the_post(); ?>
                                        <div class="weekly3-single">
                                            <div class="weekly3-img">
                                            <?php the_post_thumbnail('weekly-news', array('class' => 'img-fluid'));?>
                                            </div>
                                            <div class="weekly3-caption">
                                                <h4><a href="<?php the_title();?>"><?php the_title();?></a></h4>
                                                <p><?php echo get_the_date();?></p>
                                            </div>
                                        </div> 
                                        <?php endwhile; wp_reset_postdata();?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>           
    <!-- End Weekly-News -->


  <?php if(is_active_sidebar('news_ads_section_b4_footer_widget_ads')):?>
  <!-- banner-last Start -->
  <div class="banner-area gray-bg pt-90 pb-90">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10 col-md-10">
                    <div class="banner-one">
                        <?php  dynamic_sidebar('news_ads_section_b4_footer_widget_ads');?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- banner-last End -->
    <?php endif;?>
    



<?php get_footer();?>