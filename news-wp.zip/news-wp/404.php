<?php get_header();?>

<section class="404 section-padding">
<div class="container">
            <div class="row"></div>
<div class="heading-block text-center mb-3">
            <h4><?php _e("Ooopps! The Page you were looking for, couldn't be found.", 'news-wp')?></h4>
            <span class="mb-3"><?php _e("Try searching for the best match below:", 'news-wp')?></span><br/>
            <?php get_search_form();?>
        </div>

			</div>
</section>



<?php get_footer();?>